package com.example.appproposal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Gen41 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gen41);
    }
}